﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheRects
{
    public class GradeInfo
    {
        public Scenario Scenario;

        public int Iteration;

        public double Value;

        public double Seconds;
    }
}
